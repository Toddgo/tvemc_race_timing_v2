<?php
return [
  'host'     => 'localhost',
  'username' => 'tvemc_raceadmin',
  'password' => 'SBCrnO]cLqs-?4$fC',     // WAS TY[.K@&R?UWZ=H^,
  'dbname'   => 'tvemc_race_timing',
  'origins'  => [
      'https://tvemc.org',
      'https://www.tvemc.org',
      'https://tvemcdb.tail37eb46.ts.net',
      'http://localhost',
      'http://127.0.0.1'
  ],
  'race_title'  => 'KH Races – Race Timing',
  'hq_password' => 'Jesse2026!'
];


